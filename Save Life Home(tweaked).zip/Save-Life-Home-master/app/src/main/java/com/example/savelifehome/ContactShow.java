package com.example.savelifehome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ContactShow extends AppCompatActivity {

    String name;
    int Phone;
    String info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_show);

        TextView name =  (TextView)findViewById(R.id.NamePerson);
        TextView num = (TextView)findViewById(R.id.PhonePerson);
        TextView info = (TextView)findViewById(R.id.InfoPerson);


    }
}