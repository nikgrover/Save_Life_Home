package com.example.savelifehome;

public class model_Testcenter {

    private String mtTitle;

    public String getMtTitle() {
        return mtTitle;
    }

    public void setMtTitle(String mtTitle) {
        this.mtTitle = mtTitle;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    private String mDescription;

}
